#include<iostream>
using namespace std;
//int main()
//{
//	int a , b , c;
//	cout<<"enter the number"<<endl;
//	cin>>a;
//	cin>>b;
//	c=a+b;
//	cout<<"the value is "<<c<<endl;
//}
int main()
{
 int8_t a 200;
 uint8_t b=100;
 cout<<(int)a;
 cout<<(int)b;
	
}
