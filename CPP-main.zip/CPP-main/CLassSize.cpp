// #include<iostream>
// using namespace std;

// class Base {
//     int x;    
//     int* p;   
//     char* q;  
//     float f;
//     char s;  
//     bool b;   
// };

// int main() {
//     cout << "Size of Base class: " << sizeof(Base) << " bytes" << endl;
//     return 0;
// }
#include <iostream>

class Base {
    int x;
    int* p;
    char* q;
    float f;
    char s;
    bool b;
};

size_t CalculateSize(Base* obj) {
    // Assuming obj points to an instance of the Base class
    char* start = reinterpret_cast<char*>(obj);
    char* end = reinterpret_cast<char*>(&obj->b) + 1;  // Add 1 for the last member

    return end - start;
}

int main() {
    Base obj;

    // Calculate size manually
    size_t size = CalculateSize(&obj);

    std::cout << "Manually calculated size of Base class: " << size << " bytes" << std::endl;

    return 0;
}
