#include<iostream>
using namespace std;
class Base
{
 public:
 Base()
 {
    cout << "Base Class Default Constructor  : 1 " << endl;
 }

 Base(int x)
 {
    cout << "Base Class parameter Constructor :  3 " << endl;
 }
 ~Base()
 {
    cout << "Base Class Destructor : 6  "  << endl;
 }
};

class child: public Base
{
public:
child()
{
    cout << "Child Class Default Constructor : 2 " << endl;
}
child(int f)
{
    cout << "Child Class parameter Constructor : 4 " << endl;
}
~child()
{
    cout << "child class Destructor : 5 " << endl;
}
};

int main()
{
   child c;
   child s(23);
}