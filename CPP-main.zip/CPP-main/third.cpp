#include<iostream>
using namespace std;
int main()
{
	int a , b , c;
	cout<<"enter the number"<<endl;
	cin>>a;
	cin>>b;
	c=a+b;
	cout<<"the value is "<<c<<endl;
}
