#include <iostream>
using namespace std;
class Base
{
public:
   virtual void Find()
    {
        cout << " BASE " << endl;
    }
};
class Child : public Base
{
public:
    void Find()
    {
        cout << " Child " << endl;
    }
};
int main()
{
   Base *b = new Child();
   b->Find();
}