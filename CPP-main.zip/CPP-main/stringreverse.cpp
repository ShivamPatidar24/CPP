//#include<iostream>
//#include<string>
//#include<cstring>
//using namespace std;
//char *My_rev(char *str)
//{
//  int i,len=0,n;
//  char temp;
//  len=strlen(str);
//  n=len-1;
//  for(i = 0; i <=(len/2); i++)
//  {
//    temp=str[i];
//    str[i]=str[n];
//    str[n]=temp;
//    n--;
//  }
//  return str;
//}
//int main()
//{ 
//    char My_string[]="ihs tap";
//	cout<<"Reverse string using My_rev()...\n";
//    My_rev(My_string);
//	cout<<My_string;
//    return 0;
//}
//
//#include<iostream>
//#include<cstring>
//using namespace std; 
//int main() 
//{ 
//    char str[] ="Journal Dev reverse example"; 
//    strrev(str);
//	cout<<"\n"<<str; 
//    return 0;
//}
//
//
//#include<iostream>
//#include<string.h>
//using namespace std;
//
//int main()
//{
//    char a[40];
//    cin.getline(a, 40);
//    int l = strlen(a);
//    for(int i=l; i>=0; i--)
//    {
//        cout<<a[i];
//    }
//}

//#include <algorithm> 
//#include<iostream>
//#include<string>
//using namespace std; 
//int main() 
//{ 
//    string str;
//    cin>>str;
//    reverse(str.begin(), str.end()); 
//	cout<<"\n"<<str; 
//    return 0;
//}
