#include<iostream>
int main()
{
//	std::string s1 ;
	char s2[50];
	std::cin.getline(s2,50);
	std::cout<<s2;
}
